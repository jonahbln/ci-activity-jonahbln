/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable no-multiple-empty-lines */
/* eslint-disable brace-style */
/* eslint-disable @typescript-eslint/indent */

import { ActionKeys } from '../enums/action-keys.enum';
import { NumericKeys } from '../enums/numeric-keys.enum';
import { OperatorKeys } from '../enums/operator-keys.enum';
import { ICalculatorModel } from '../interfaces/calculator-model.interface';

export class CalculatorModel implements ICalculatorModel {

  private _buffer: string = '';
  private _operatorbuffer: string = '';


  public pressNumericKey(key: NumericKeys): void {
    this._buffer += key;
  }

  public pressOperatorKey(key: OperatorKeys): void {
    this._buffer += key;
    this._operatorbuffer += key;
  }

  public pressActionKey(key: ActionKeys): void {
    const args: number[] = [];
    let tempArg: number = 0;
    let decIndex: number = 1;
    let dot: boolean = false;
    switch (key) {
      case ActionKeys.EQUALS :
        for (let i: number = 0; i < this._buffer.length; i++) {
          if (this._buffer.charCodeAt(i) >= 48 && this._buffer.charCodeAt(i) <= 57) {
            if (!dot) {
              tempArg = tempArg * 10 + this._buffer.charCodeAt(i) - 48;
            }
            else {
              tempArg = tempArg + ((this._buffer.charCodeAt(i) - 48) / (Math.pow(10, decIndex++)));
            }
          }
          else {
            if (this._buffer.charAt(i) === '.') {
              dot = true;
            }
            else {
              dot = false;
              decIndex = 0;
              args.push(tempArg);
              tempArg = 0;
            }
          }
        }
        args.push(tempArg);
        args.reverse();
        tempArg = args.pop();

        for (let i: number = 0; i < this._operatorbuffer.length; i++) {
            tempArg = this.operateHelper(tempArg, args.pop() , this._operatorbuffer.charCodeAt(i));
          }
        this._buffer = tempArg.toString();
        break;

      case ActionKeys.CLEAR :
          this._buffer = '';
      break;

      case ActionKeys.DOT :
          this._buffer += '.';
      break;

      default :
        throw new Error('Invalid action key');
        break;
    }
  }



  public display(): string {
    return this._buffer;
  }

  private operateHelper(arg1: number, arg2: number, operator: number): number {
    switch (operator) {
      case 42 :
        return arg1 * arg2;
      break;
      case 43 :
        return arg1 + arg2;
      break;
      case 45 :
        return arg1 - arg2;
      break;
      case 47 :
        return arg1 / arg2;
      break;
      default :
        return 0;
      break;
  }

}
}
